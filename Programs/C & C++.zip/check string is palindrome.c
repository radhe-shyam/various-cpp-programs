#include<stdio.h>
#include<conio.h>
#include<string.h>
void palindrome(char *s,int l);
main()
{
      int l;
      char c[50];
      char *ptr;
      printf("Enter the string\n");
      scanf("%s",c);
      //ptr=c;
      l=strlen(c);
      palindrome(c,l);
      getch();
}
void palindrome(char *s,int l)
{
     int i,j,flag=0;
     for(i=0,j=l-1;i<j;i++,j--)
     {
           if(*(s+i)==*(s+j))
                         flag=1;
           else
           {
               flag=0;
               break;
           }
     }
     if(flag==1)
          printf("it is palindrome\n");
     else
         printf("it is not a palindrome\n");
}
