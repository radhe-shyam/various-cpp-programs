#include<stdio.h>
#include<conio.h>
main()
{
      int a[20],*p,i,n,sum=0;
      printf("Enter n\n");
      scanf("%d",&n);
      printf("Enter %d elements",n);
      for(i=0;i<n;i++)
      {
           scanf("%d",&a[i]);
      }
      p=a;
      for(i=0;i<n;i++)
      {
       sum=sum+*p++;
      }
      printf("Sum %d",sum);
      getch();
}
