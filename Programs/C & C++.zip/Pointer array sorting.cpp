#include<stdio.h>
#include<conio.h>
#include<string.h>
int main()
{
	int i,j,n;
	char a[10][20],*ptr,*temp,*ptr1,str[20];
	temp=str;
	printf("Enter number of Strings you want: ");
	scanf("%d",&n);
	printf("Enter %d Strings: \n",n);
	for(i=0;i<n;i++)
	scanf("%s",a[i]);
	for(i=0;i<n;i++)
	    {
			ptr=a[i];
		for(j=i+1;j<3;j++)
			{
				ptr1=a[j];
				if(strcmp(ptr,ptr1)>0)
					{
						strcpy(temp,ptr);
						strcpy(ptr,ptr1);
						strcpy(ptr1,temp);
					}
			}
		}
	printf("Sorted Array: \n");
    for(i=0;i<5;i++)
	printf("%s\n",a[i]);
	getch();
	return 0;
}
